#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
 *   author:  josuerom
 *   created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}
**/
import java.util.Scanner;
import java.util.Arrays;
import static java.lang.Math.*;

public class ${NAME} {
   private final boolean DEBUG = false;

   public static void main(String[] args) {
      readInput();
   }

   public static void solution(int[] vi) {
   }

   public static void readInput() {
      Scanner sc = new Scanner(System.in);
      int tt, vi[];
      tt = sc.nextInt();
      while (tt-- > 0) {
         int n = sc.nextInt();
         vi = new int[n];
         for (int i = 0; i < n; i++) {
            vi[i] = sc.nextInt();
         }
         solution(vi);
      }
      sc.close(); System.out.close();
   }
}