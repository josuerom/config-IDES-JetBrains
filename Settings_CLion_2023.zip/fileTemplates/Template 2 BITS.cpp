/**
 *   █▀█  █▀▀▄ ─▀─ ▀▀█▀▀ █▀▀ ▄▀ ▀▄
 *   ─▄▀  █▀▀▄ ▀█▀ ──█── ▀▀█ █─ ─█
 *   █▄▄  ▀▀▀─ ▀▀▀ ──▀── ▀▀▀ ▀▄ ▄▀
 *   created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}
**/
#[[#include]]# <bits/stdc++.h>
using namespace std;

#[[#ifdef]]# DEBUG
#[[#include]]# "../debug.h"
#[[#else]]#
#[[#define]]# debug(...) 42
#[[#endif]]#

const int N = 1e6 + 7;
int a[N], n;

void solve() {
}

int main() {
   ios::sync_with_stdio(false);
   cin.tie(0);
   int tt;
   cin >> tt;
   while (tt--) {#[[$END$]]#
      solve();
   }
   return 0;
}