/**
 *   author:  josuerom
 *   created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}
**/
#[[#include]]# <bits/stdc++.h>
using namespace std;

#[[#ifdef]]# DEBUG
#[[#include]]# "debug.h"
#[[#else]]#
#[[#define]]# debug(...) 42
#[[#endif]]#

#[[#define]]# ll  long long
#[[#define]]# pb  push_back
#[[#define]]# br  '\n'



void solve() {
}

int main() {
   ios::sync_with_stdio(false);
   cin.tie(0);
   int tt = 1;
   #[[$END$]]#cin >> tt;
   for (int nc = 1; nc <= tt; nc++) {
#[[#ifdef]]# LOCAL
      cout << "-- Case #" << nc << " --\n";
      solve();
#[[#else]]#
      solve();
#[[#endif]]#
   }
   return 0;
}