#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
 *   @author: 2 bits  @created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}
**/
import java.util.Scanner;
import java.util.Arrays;
import static java.lang.Math.*;

public class ${NAME} {
   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      
      sc.close(); System.out.close();
   }
}