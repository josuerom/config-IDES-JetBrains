#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
 *   author:  josuerom
 *   created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}
**/
import java.util.Scanner;
import java.util.Arrays;
import static java.lang.Math.*;

public class ${NAME} {
   private final boolean DEBUG = false;

   public static void main(String[] args) {
      readInput();
   }

   public static void solve(int[] vi) {
   }

   public static void readInput() {
      Scanner sc = new Scanner(System.in);
      int tt = sc.nextInt();
      while (tt-- > 0) {
         int N = sc.nextInt();
         int vi = new int[N];
         for (int i = 0; i < N; i++) {
            vi[i] = sc.nextInt();
         }
         solve(vi);
      }
      sc.close(); System.out.close();
   }
}