#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
 *   Team: 2 Bits - Created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}
**/
import java.util.Scanner;
import java.util.Arrays;
import static java.lang.Math.*;

public class ${NAME} {
   private final boolean DEBUG = false;

   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      
      sc.close(); System.out.close();
   }
}