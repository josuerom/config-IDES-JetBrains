#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/*  @team: 2 Bits()  @created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}  */
import java.util.Scanner;
import java.util.Arrays;
import static java.lang.Math.*;

public class ${NAME} {
   private static final boolean DEBUG = false;

   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      
      sc.close(); System.out.close();
   }
}