#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
    ░░█ █▀█ █▀ █░█ █▀▀ █▀█ █▀█ █▀▄▀█
    █▄█ █▄█ ▄█ █▄█ ██▄ █▀▄ █▄█ █░▀░█
    created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}
**/
import java.util.*;

public class ${NAME} {
   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      #[[$END$]]
      System.exit(0);
   }
}