/**
 *   author:  josuerom
 *   created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}
**/
#[[#include]]# <bits/stdc++.h>

using namespace std;

#[[#ifdef]]# josuerom
   #[[#include]]# "debug.h"
#[[#else]]#
   #[[#define]]# debug(...) 42
#[[#endif]]#

int main() {
   ios::sync_with_stdio(false);
   cin.tie(0);
   
   return 0;
}