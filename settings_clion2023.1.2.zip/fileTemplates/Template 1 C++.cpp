/**
 *   author:  josuerom
 *   created: ${DAY}/${MONTH}/23 ${HOUR}:${MINUTE}:${SECOND}
**/
#[[#pragma]]# GCC optimize("0fast,unroll-loops,fast-math,no-stack-protector")
#[[#pragma]]# GCC target("avx2")

#[[#include]]# <bits/stdc++.h>

using namespace std;

#[[#define]]# all(x) (x).begin(),(x).end()
#[[#define]]# len(x) (int) (x).size()
#[[#define]]# ll long long
#[[#define]]# pb push_back
#[[#define]]# mp make_pair
#[[#define]]# ss second
#[[#define]]# ff first

int main() {
   ios::sync_with_stdio(false);
   cin.tie(0);
   
   return 0;
}